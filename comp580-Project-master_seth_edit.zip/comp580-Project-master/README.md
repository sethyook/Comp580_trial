# Space-bug Math
## A voice-controlled HTML5 puzzle game


### Browser support
Currently this game can only be played on Google Chrome.

### Making Changes to the demo
